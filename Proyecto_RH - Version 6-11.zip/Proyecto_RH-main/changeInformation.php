<!-- 
<?php include "includes/header.php" ?>
<section>
    <div>
        <form action="" class="formPage">
            <fieldset>
                <div>
                    <input type="text" name="number" id="number">
                </div>
                <div>
                    <input type="text" name="name" id="name">
                </div>
                <div>
                    <input type="text" name="lastName" id="lastName">
                </div>
                <div>
                    <input type="text" name="email" id="email">
                </div>
                <div>
                    <input type="text" name="gender" id="gender">
                </div>
                <div>
                    <input type="text" name="age" id="age">
                </div>
                <div>
                    <input type="text" name="phoneNumber" id="phoneNumber">
                </div>
                <div>
                    <input type="text" name="password" id="password">
                </div>
                <div>
                    <button type="submit">Change data</button>
                </div>
                <div>
                    <button>Cancel</button>
                </div>
            </fieldset>
        </form>
    </div>
</section>

<?php include "includes/footer.php" ?>
-->


