<?php 
    include "includes/headerlogin.php";
?>
<body>
    <div class="btn-container">
    <h2>Human resources</h2>
    <h3>Welcome to the main menu</h3>
    <p>Select one of the following options</p>
        <a href="marcados.php" class="btn btn-marcado" aria-label="Mark Attendance">
            <i class="fas fa-check-circle"></i> Mark Attendance
        </a>
        <a href="Session/login.php" class="btn btn-portal" aria-label="Enter Employment Portal">
            <i class="fas fa-door-open"></i> Enter Employment Portal
        </a>
    </div>
</body>
</html>