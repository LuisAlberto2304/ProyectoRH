<?php
    //include "headerlogin.php";
?>
<body>
    <h2>Bienvenido al marcado de entrada o salida</h2>

    <section>
        <div>
            <input type="text" name="NoControl">
            <button>Marcar</button>
        </div>
    </section>
</body>