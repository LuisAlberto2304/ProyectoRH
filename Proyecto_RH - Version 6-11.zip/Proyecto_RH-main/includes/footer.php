<section>
    <footer>
        <div>
            <p>
                All rights reserved by: Company
            </p>
        </div>
    </footer>
</section>

</body>
</html>